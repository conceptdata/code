<?php
/*  Program name: emptyForm.php
 *  Description:  Display a form with no fields.
 */
?>
<html>
<head><title>Empty Form</title></head>
<body>
<p>When you are ready to see the next page, click Next</p>
<form action="newpage.php" method="POST">
  <input type="submit" value="Next" style="margin: .5in" />
</form>
</body></html>
