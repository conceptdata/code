<?php
/*  Program name: display_form.php (1-2)
 *  Description:  Script displays a form.
 */
include("form_checkbox.inc");
?>
